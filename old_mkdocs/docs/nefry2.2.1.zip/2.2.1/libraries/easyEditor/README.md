﻿# easyEditer

easyEditerはNefryのWebserver上で動く、簡単なプログラムを書くことができるエディタです。

現在digitalWrite,analogWrite,delayをつかうことができます。
Nefryがリセットされるとプログラムが消去されてしまうので、あくまでも簡単に動かす用途向きです。

プログラムを書き換えずに試すことができるので、試作にぴったりです。

-------------------------



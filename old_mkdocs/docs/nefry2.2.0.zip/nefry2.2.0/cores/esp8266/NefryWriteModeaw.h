#ifndef Nefry_Writew_h
#define Nefry_Writew_h
typedef void(*FUNC_POINTER)(void); //�֐��|�C���^��typedef
extern FUNC_POINTER fsetup, floop;

//extern Nefry_Write NefryWriteMode;
#endif

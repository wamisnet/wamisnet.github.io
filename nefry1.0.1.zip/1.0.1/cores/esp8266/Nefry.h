#ifndef Nefry_h
#define Nefry_h

#include <ESP8266WiFi.h>
#include <ESP8266mDNS.h>
#include <ESP8266WebServer.h>
#include <WiFiClient.h>
#include <EEPROM.h>
#include <Adafruit_NeoPixel.h>
#include <ESP8266httpUpdate.h>	

#define WIFI_CONF_FORMAT {0, 0, 0, 1}
#define NAME_PREF "Nefry-"
#define WIFI_CONF_START 0

class Nefry
{
public:
	bool pushSW_flg;
	String network_html;
	String network_list, input_console;

	
    void nefry_init();
    void nefry_loop();
   
	void println(float text);
	void println(double text);
	void println(char text);
	void println(int text);
	void println(long text);
	void println(unsigned char text);
	void println(unsigned int text);
	void println(unsigned long text);
	void print(float text);
	void print(double text);
	void print(char text);
	void print(int text);
	void print(long text);
	void print(unsigned char text);
	void print(unsigned int text);
	void print(unsigned long text);
	void print(String text);
	void println(String text);
	void nefry_console();
	int available();
	String read();

	bool push_SW();
	//void webpage(const char url[20],String page,String link);
	
protected:
    ESP8266WebServer _server;
	Adafruit_NeoPixel _RGBLED;

private:
	
    void printWiFiConf(void);
    bool loadWiFiConf();
    void saveWiFiConf(void);
    void setDefaultModuleId(char* dst);
    void resetModuleId(void);
    void scanWiFi(void);
    int  waitConnected(void);
    void printIP(void);
    void setupWiFiConf(void);
    void setupWeb_local_Update(void);
    void setupWeb(void);
    String escapeParameter(String param);
    //void user_webpage();
 
	void RGB_LED(char r,char g,char b);
    void RGB_LED(char r,char g,char b,char w);
	void RGB_LED_blink(char r,char g,char b,int wait,int loop);

};

#endif

//
//  nefry.c
//  
//
//  Created by hoehoe on 2015/11/15.
//

#include "Nefrylib.h"
Nefry _nefrycore;
Adafruit_NeoPixel _NefryLED[16];
void Nefrylib::Nefry_LED(char r, char g, char b, char w, char pin,int num) {
	_NefryLED[pin].setBrightness(w);
	_NefryLED[pin].setPixelColor(num, r, g, b);
	_NefryLED[pin].show();
}
void Nefrylib::Nefry_LED_blink(char r, char g, char b, int wait, int loop, char pin ) {
	int i = 0;
	while (i < loop) {
		Nefry_LED(r, g, b, pin);
		delay(wait);
		Nefry_LED(r, g, b, pin, 0);
		delay(wait);
		i++;
	}
}
bool Nefrylib::pushSW() {
	bool pushSW_flg = 0;

	pinMode(4, INPUT_PULLUP);
	if (digitalRead(4) == LOW) {
		Nefry_LED(0xff, 0x00, 0x00, 7);
		delay(1000);
		pushSW_flg = 1;

	}
	return pushSW_flg;
}
void Nefrylib::setup() {
	_NefryLED[7] = Adafruit_NeoPixel(1, 0, NEO_RGB + NEO_KHZ800);
	_NefryLED[7].begin();
}
void Nefrylib::reset() {
	ESP.restart();
}
void Nefrylib::sleep(int sec) {
	ESP.deepSleep(sec * 1000 * 1000, WAKE_RF_DEFAULT);
	delay(1000);
}

void Nefrylib::ledbegin(int num, int pin, uint8_t t = NEO_GRB + NEO_KHZ800) {
	_NefryLED[pin] = Adafruit_NeoPixel(num, pin, t);
}
void Nefrylib::println(float text){println(String(text));}
void Nefrylib::println(double text){println(String(text));}
void Nefrylib::println(char text){println(String(text));}
void Nefrylib::println(int text){println(String(text));}
void Nefrylib::println(long text){println(String(text));}
void Nefrylib::println(unsigned char text){println(String(text));}
void Nefrylib::println(unsigned int text){println(String(text));}
void Nefrylib::println(unsigned long text){println(String(text));}
void Nefrylib::print(float text){print(String(text));}
void Nefrylib::print(double text){print(String(text));}
void Nefrylib::print(char text){print(String(text));}
void Nefrylib::print(int text){print(String(text));}
void Nefrylib::print(long text){print(String(text));}
void Nefrylib::print(unsigned char text){print(String(text));}
void Nefrylib::print(unsigned int text){print(String(text));}
void Nefrylib::print(unsigned long text){print(String(text));}
void Nefrylib::print(String text){
	_nefrycore.print(text);
}
void Nefrylib::println(String text){
	_nefrycore.println(text);
}
int Nefrylib::available(){
	return _nefrycore.available();
}
String Nefrylib::read(){
	return _nefrycore.read();
}
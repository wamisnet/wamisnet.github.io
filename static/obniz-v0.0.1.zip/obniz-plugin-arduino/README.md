# Arduino core for the obniz

Arduinoとしてobnizの機能を扱えるようになるプラグインになります。
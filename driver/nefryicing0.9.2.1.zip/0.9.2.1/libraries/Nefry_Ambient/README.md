# Ambient_Nefry library

[Ambient](https://ambidata.io)はIoTクラウドサービスです。 マイコンから送られたデーターを受信し、蓄積し、可視化(グラフ化)します。

Ambient ESP8266 library をラッピングしています。
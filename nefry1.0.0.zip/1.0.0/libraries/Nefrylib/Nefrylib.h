#ifndef Nefrylib_h
#define Nefrylib_h

#include <Adafruit_NeoPixel.h>

class Nefrylib
{
public:
    void setup();
	void RGB_LED(char r,char g,char b);
    void RGB_LED(char r,char g,char b,char w);
	void RGB_LED_blink(char r,char g,char b,int wait,int loop);
	void reset();
	void sleep(int sec);
    bool pushSW();
protected:
    Adafruit_NeoPixel _RGBLED;
    
private:
	
};

#endif

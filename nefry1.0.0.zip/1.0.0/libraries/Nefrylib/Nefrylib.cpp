//
//  nefry.c
//  
//
//  Created by hoehoe on 2015/11/15.
//


#include "Nefrylib.h"

void Nefrylib::RGB_LED(char r, char g, char b) {
	RGB_LED(r, g, b, 120);
}
void Nefrylib::RGB_LED(char r, char g, char b, char w) {
	_RGBLED.setBrightness(w);
	_RGBLED.setPixelColor(0, r, g, b);
	_RGBLED.show();
}
void Nefrylib::RGB_LED_blink(char r, char g, char b, int wait, int loop) {
	int i = 0;
	while (i < loop) {
		RGB_LED(r, g, b);
		delay(wait);
		RGB_LED(r, g, b, 0);
		delay(wait);
		i++;
	}
}
bool Nefrylib::pushSW() {
	bool pushSW_flg = 0;

	pinMode(4, INPUT_PULLUP);
	if (digitalRead(4) == LOW) {
		RGB_LED(0xff, 0x00, 0x00);
		delay(1000);
		pushSW_flg = 1;

	}
	return pushSW_flg;
}
void Nefrylib::setup() {
	_RGBLED = Adafruit_NeoPixel(1, 0, NEO_RGB + NEO_KHZ800);
	_RGBLED.begin();
}
void Nefrylib::reset() {
	ESP.restart();
}
void Nefrylib::sleep(int sec) {
	ESP.deepSleep(sec * 1000 * 1000, WAKE_RF_DEFAULT);
	delay(1000);
}
